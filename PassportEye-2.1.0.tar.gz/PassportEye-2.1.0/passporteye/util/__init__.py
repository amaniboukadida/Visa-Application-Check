'''
PassportEye::Util: Utility tools.

Author: Konstantin Tretyakov
License: MIT
'''
