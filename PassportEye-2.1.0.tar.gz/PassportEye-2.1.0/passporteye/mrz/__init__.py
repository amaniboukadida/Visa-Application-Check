'''
PassportEye::MRZ: Machine-readable zone extraction and parsing.

Author: Konstantin Tretyakov
License: MIT
'''

